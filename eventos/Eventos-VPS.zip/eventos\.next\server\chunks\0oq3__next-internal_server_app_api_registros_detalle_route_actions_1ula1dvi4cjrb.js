module.exports=[38899,(e,o,d)=>{}];

//# sourceMappingURL=0oq3__next-internal_server_app_api_registros_detalle_route_actions_1ula1dvi4cjrb.js.map