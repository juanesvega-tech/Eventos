var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/comida/route.js")
R.c("server/chunks/[root-of-the-server]__05m0swusvk14q._.js")
R.c("server/chunks/[root-of-the-server]__15yhzwso-e9s6._.js")
R.c("server/chunks/eventos_0m250tv08xm5z._.js")
R.c("server/chunks/eventos__next-internal_server_app_api_comida_route_actions_1icwwkrhd6kna.js")
R.m(66071)
module.exports=R.m(66071).exports
