var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/acompanantes/resumen/route.js")
R.c("server/chunks/[root-of-the-server]__06bg-gumkkq63._.js")
R.c("server/chunks/eventos_1sm7miq18ufna._.js")
R.c("server/chunks/[root-of-the-server]__06xsw8hmnszc0._.js")
R.c("server/chunks/12wx_next_1hawuj_ty4qvt._.js")
R.c("server/chunks/0oq3__next-internal_server_app_api_acompanantes_resumen_route_actions_09wwn9p6dw83t.js")
R.m(71041)
module.exports=R.m(71041).exports
