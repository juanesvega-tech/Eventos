var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/comida/reporte/route.js")
R.c("server/chunks/[root-of-the-server]__00chz9ya830w9._.js")
R.c("server/chunks/eventos_0d2zzke7u2dib._.js")
R.c("server/chunks/[root-of-the-server]__06xsw8hmnszc0._.js")
R.c("server/chunks/12wx_next_1hawuj_ty4qvt._.js")
R.c("server/chunks/eventos__next-internal_server_app_api_comida_reporte_route_actions_18rctyv96vqzm.js")
R.m(61268)
module.exports=R.m(61268).exports
