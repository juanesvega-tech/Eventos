module.exports=[88667,(e,o,d)=>{}];

//# sourceMappingURL=0oq3__next-internal_server_app_api_acompanantes_resumen_route_actions_09wwn9p6dw83t.js.map