var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/registros/detalle/route.js")
R.c("server/chunks/12wx_open_index_1q15akq5ttftt.js")
R.c("server/chunks/[root-of-the-server]__1osgy9pd9a_7c._.js")
R.c("server/chunks/[root-of-the-server]__06xsw8hmnszc0._.js")
R.c("server/chunks/12wx_next_1hawuj_ty4qvt._.js")
R.c("server/chunks/eventos_1_tqy798ee5w6._.js")
R.c("server/chunks/0oq3__next-internal_server_app_api_registros_detalle_route_actions_1ula1dvi4cjrb.js")
R.m(4077)
module.exports=R.m(4077).exports
