var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/eventos/route.js")
R.c("server/chunks/[root-of-the-server]__0b5jwe2wk_tmj._.js")
R.c("server/chunks/eventos_02clkcas_spz3._.js")
R.c("server/chunks/[root-of-the-server]__06xsw8hmnszc0._.js")
R.c("server/chunks/12wx_next_1hawuj_ty4qvt._.js")
R.c("server/chunks/eventos__next-internal_server_app_api_eventos_route_actions_0_qc38--ins5h.js")
R.m(87955)
module.exports=R.m(87955).exports
