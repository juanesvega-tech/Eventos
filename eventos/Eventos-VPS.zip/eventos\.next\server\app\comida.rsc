#1:"$Sreact.fragment"
2:"/_next/static/chunks/2jpgc-kvq-n38.js"
3:I[98285,["$2"],"default"]
4:I[53744,["$2"],"default"]
9:I[31213,["$2"],"ClientPageRoot"]
a:"/_next/static/chunks/0rp2zwz44xftg.js"
b:"/_next/static/chunks/39ok_17lh00wf.js"
c:I[83016,["$2","$a","$b"],"default"]
d:I[61806,["$2"],"OutletBoundary"]
e:"$Sreact.suspense"
11:"ViewportBoundary"
12:I[61806,["$2"],"$11"]
14:"MetadataBoundary"
15:I[61806,["$2"],"$14"]
18:I[31462,["$2"],"default",1]
:HL["/_next/static/chunks/1rgubu1t4f-82.css","style"]
5:X
7:X
10:X
8:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","$L9",null,{"Component":"$c","serverProvidedParams":null}],[["$","script","script-0",{"src":"/_next/static/chunks/0rp2zwz44xftg.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/39ok_17lh00wf.js","async":true,"nonce":"$undefined"}]],["$","$Ld",null,{"children":["$","$e",null,{"name":"Next.MetadataOutlet","children":"$@f"}]}]]}],"p":true,"v":"$10"}}]]
6:[["children",{"s":"comida","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","div",null,{"className":"relative min-h-screen overflow-hidden bg-[#f3f5ef]","children":[["$","div",null,{"className":"pointer-events-none absolute inset-x-0 top-0 h-[330px] bg-[#14320f]","aria-hidden":"true"}],["$","div",null,{"className":"pointer-events-none absolute -right-40 -top-52 h-[520px] w-[520px] rounded-full border-[90px] border-[#e2b808]/10","aria-hidden":"true"}],["$","div",null,{"className":"pointer-events-none absolute left-0 top-[280px] h-20 w-1/3 rounded-r-full bg-[#e2b808]/10 blur-3xl","aria-hidden":"true"}],["$","div",null,{"className":"relative z-10","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]]}],"p":true,"v":"$7"},"c":"$Q8"}]]
17:X
19:X
1a:X
0:{"P":null,"c":["","comida"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1rgubu1t4f-82.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/2jpgc-kvq-n38.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"es","children":["$","body",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":true,"v":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L12",null,{"children":"$L13"}],["$","$L15",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$e",null,{"name":"Next.Metadata","children":"$L16"}]}],null]}],null]}],"p":true,"v":"$17"}},"m":"$undefined","G":["$18",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1rgubu1t4f-82.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$19","s":"$1a","a":"$@1b","l":"$undefined","p":"$undefined","d":"$undefined","b":"WtEMasfYzOSD1mSbUHnl-","u":"$@1c"}
10:C
1a:300
13:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
f:null
16:[["$","title","0",{"children":"Control de comida | Dashboard de eventos"}],["$","meta","1",{"name":"description","content":"Consulta de consumos por servicio para trabajadores y acompañantes."}]]
1a:C
17:C
19:C
7:C
5:C
1c:false
1b:null
