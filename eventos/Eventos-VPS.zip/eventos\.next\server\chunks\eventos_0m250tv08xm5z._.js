(()=>{"use strict";module.exports=[66071,e=>{var o=e.i(49271),r=e.i(77911),t=e.i(282),s=e.i(27149),a=e.i(8987),i=e.i(41178),n=e.i(71678),c=e.i(66403),u=e.i(13696),l=e.i(32924),R=e.i(95479),d=e.i(54823),m=e.i(85486),p=e.i(17128),T=e.i(69375),N=e.i(93695),I=e.i(57564);e.i(23287);var C=e.i(64413);let g=new o.AppRouteRouteModule({definition:{kind:r.f.APP_ROUTE,page:"/api/comida/route",pathname:"/api/comida",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/eventos/src/app/api/comida/route.js",nextConfigOutput:"standalone",userland:()=>e.r(41417),...{}}),{workAsyncStorage:S,workUnitAsyncStorage:E,serverHooks:A}=g;async function v(e,o,t){t.requestMeta&&(0,s.R)(e,t.requestMeta),g.isDev&&(0,s.i)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let S="/api/comida/route";S=S.replace(/\/index$/,"")||"/";let E=await g.prepare(e,o,{srcPage:S,multiZoneDraftMode:!1});if(!E)return o.statusCode=400,o.end("Bad Request"),null==t.waitUntil||t.waitUntil.call(t,Promise.resolve()),null;let{buildId:A,deploymentId:v,params:h,nextConfig:b,parsedUrl:M,isDraftMode:P,prerenderManifest:D,routerServerContext:f,isOnDemandRevalidate:L,revalidateOnlyGenerated:O,resolvedPathname:w,clientReferenceManifest:x,serverActionsManifest:y,previewProps:H}=E,U=(0,n.f)(S),F=!!D.routes[w]&&(g.isDev||(0,I.f)(w,g.cacheOwner,D.routes[w])),j=!!(D.dynamicRoutes[U]||F),q=async()=>((null==f?void 0:f.render404)?await f.render404(e,o,M,!1):o.end("This page could not be found"),null);if(j&&!P){let e=D.dynamicRoutes[U];if(e&&!1===e.fallback&&!F){if(b.adapterPath)return await q();throw new N.NoFallbackError}}let W=null;!j||g.isDev||P||(W="/index"===(W=w)?"/":W),y&&x&&(0,i.f)({page:S,clientReferenceManifest:x,serverActionsManifest:y});let k=e.method||"GET",B=(0,a.v)(),V=B.getActiveScopeSpan(),_=!!(null==f?void 0:f.isWrappedByNextServer),G=!!(0,s.w)(e,"minimalMode"),J=(0,s.w)(e,"incrementalCache")||await g.getIncrementalCache(e,b,H,D,G);null==J||J.resetRequestCache(),globalThis.__incrementalCache=J;let $={params:h,previewProps:H,renderOpts:{experimental:{authInterrupts:!!b.experimental.authInterrupts,useCacheTimeout:b.experimental.useCacheTimeout,durableUseCacheEntries:!!b.experimental.durableUseCacheEntries},cacheComponents:!!b.cacheComponents,validationLevel:b.experimental.instantInsights.validationLevel,isDraftMode:P,incrementalCache:J,hmrRefreshHash:(0,s.w)(e,"hmrRefreshHash"),cacheLifeProfiles:b.cacheLife,staticPageGenerationTimeout:b.staticPageGenerationTimeout,waitUntil:t.waitUntil,onClose:e=>{o.on("close",e)},onAfterTaskError:void 0},sharedContext:{buildId:A,deploymentId:v}},Y=new c.x(e),K=new c.e(o),Q=u.k.fromNodeNextRequest(Y,(0,u.t)(o)),X=async({previousCacheEntry:r})=>{try{if(!G&&L&&O&&!r)return o.statusCode=404,o.setHeader("x-nextjs-cache","REVALIDATED"),o.end("This page could not be found"),null;let s=null===W?await g.handle(Q,$):await g.prerender(Q,$);e.fetchMetrics=$.renderOpts.fetchMetrics;let a=$.renderOpts.pendingWaitUntil;a&&t.waitUntil&&(t.waitUntil(a),a=void 0);let i=$.renderOpts.collectedTags;if(!j)return await (0,d.f)(Y,K,s,a),null;{let e=await s.blob(),o=(0,m.S)(s.headers);i&&(o[T.M]=i),!o["content-type"]&&e.type&&(o["content-type"]=e.type);let r=void 0!==$.renderOpts.collectedRevalidate&&!($.renderOpts.collectedRevalidate>=T.Q)&&$.renderOpts.collectedRevalidate,t=void 0===$.renderOpts.collectedExpire||$.renderOpts.collectedExpire>=T.Q?!1!==r&&r>0?b.expireTime:void 0:$.renderOpts.collectedExpire;return{value:{kind:C.x.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:o},cacheControl:{revalidate:r,expire:t}}}}catch(o){throw(null==r?void 0:r.isStale)&&await g.onRequestError(e,o,{routerKind:"App Router",routePath:S,routeType:"route",revalidateReason:(0,R.f)({isStaticGeneration:null!==W,isOnDemandRevalidate:L})},!1,f),o}},Z=async(s,i)=>{try{var n,c;let s=await g.handleResponse({req:e,nextConfig:b,cacheKey:W,routeKind:r.f.APP_ROUTE,isFallback:!1,previewProps:H,prerenderManifest:D,isRoutePPREnabled:!1,isOnDemandRevalidate:L,revalidateOnlyGenerated:O,responseGenerator:X,waitUntil:t.waitUntil,isMinimalMode:G});if(null!==s&&"error"in s)throw s.error;if(!j)return;if((null==s||null==(n=s.value)?void 0:n.kind)!==C.x.APP_ROUTE)throw Error(`Invariant: app-route received invalid cache entry ${null==s||null==(c=s.value)?void 0:c.kind}`);G||o.setHeader("x-nextjs-cache",L?"REVALIDATED":s.isMiss?"MISS":s.isStale?"STALE":"HIT"),P&&o.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let a=(0,m.G)(s.value.headers);G&&j||a.delete(T.M),!s.cacheControl||o.getHeader("Cache-Control")||a.get("Cache-Control")||a.set("Cache-Control",(0,p.f)(s.cacheControl)),await (0,d.f)(Y,K,new Response(s.value.body,{headers:a,status:s.value.status||200}));return}catch(r){if(r instanceof N.NoFallbackError||await g.onRequestError(e,r,{routerKind:"App Router",routePath:U,routeType:"route",revalidateReason:(0,R.f)({isStaticGeneration:null!==W,isOnDemandRevalidate:L})},!1,f),j)throw r;if(o.headersSent){if(s){let e=r instanceof Error?r:Error("Unknown app route error");s.recordException(e),s.setStatus({code:a.J.ERROR,message:e.message}),s.setAttribute("error.type",e.name)}o.writableEnded||o.destroyed||o.end()}else await (0,d.f)(Y,K,new Response(null,{status:500}));return}finally{(()=>{if(!s)return;let e=o.statusCode;s.setAttributes({"http.status_code":e,"next.rsc":!1}),e&&e>=500&&(s.setStatus({code:a.J.ERROR}),s.setAttribute("error.type",e.toString()));let r=B.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==l.q.handleRequest)return console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let t=r.get("next.route")||U,n=`${k} ${t}`;s.setAttributes({"next.route":t,"http.route":t,"next.span_name":n}),s.updateName(n),i&&i!==s&&(i.setAttribute("http.route",t),i.updateName(n))})()}};if(_&&V)await Z(V,void 0);else{let o=B.getActiveScopeSpan();await B.withPropagatedContext(e.headers,()=>B.trace(l.q.handleRequest,{spanName:`${k} ${S}`,kind:a.C.SERVER,attributes:{"http.method":k,"http.target":e.url}},e=>Z(e,o)),void 0,!_)}}e.s(["handler",0,v,"patchFetch",0,function(){return(0,t.f)({workAsyncStorage:S,workUnitAsyncStorage:E})},"routeModule",0,g,"serverHooks",0,A,"workAsyncStorage",0,S,"workUnitAsyncStorage",0,E])},41417,e=>{var o=e.i(8528),r=e.i(40437);async function t(e){let t=await (0,o.f)(),s=(await t.request().input("ProgramacionNro",r.sql.Decimal(10,0),Number(e)).query(`
      ;WITH ConsumosBase AS (
        SELECT DISTINCT
          re.ProgramacionNro,
          LTRIM(RTRIM(rec.RegistrosConsumosTipo)) AS TipoConsumo,
          LTRIM(RTRIM(rec.TipoServiciosCodigo)) AS CodigoServicio,
          LTRIM(RTRIM(ts.TipoServiciosNombre)) AS NombreServicio,
          CAST(rec.RegistrosConsumosFec AS DATE) AS FechaConsumo,
          CASE
            WHEN LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'PRINCIPAL'
              THEN LTRIM(RTRIM(re.PersonasDocumento))
            WHEN LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'INVITADO'
              THEN LTRIM(RTRIM(rea.RegistrosAcompDocum))
          END AS DocumentoPersona
        FROM dbo.RegistrosEventoConsumos AS rec
        INNER JOIN dbo.RegistrosEvento AS re
          ON re.RegistrosEventoNro = rec.RegistrosEventoNro
        INNER JOIN dbo.TipoServicios AS ts
          ON LTRIM(RTRIM(ts.TipoServiciosCodigo)) =
             LTRIM(RTRIM(rec.TipoServiciosCodigo))
        LEFT JOIN dbo.RegistrosEventoAcomp AS rea
          ON rea.RegistrosEventoNro = rec.RegistrosEventoNro
        WHERE re.ProgramacionNro = @ProgramacionNro
          AND LTRIM(RTRIM(rec.RegistrosConsumosTipo))
              IN ('PRINCIPAL', 'INVITADO')
          AND (
            LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'PRINCIPAL'
            OR rea.RegistrosAcompDocum IS NOT NULL
          )
      ),
      PersonasUnicas AS (
        SELECT DISTINCT
          ProgramacionNro,
          TipoConsumo,
          CodigoServicio,
          NombreServicio,
          FechaConsumo,
          DocumentoPersona
        FROM ConsumosBase
        WHERE DocumentoPersona IS NOT NULL
          AND DocumentoPersona <> ''
      )
      SELECT
        CodigoServicio,
        NombreServicio,
        SUM(
          CASE
            WHEN TipoConsumo = 'PRINCIPAL' THEN 1
            ELSE 0
          END
        ) AS Trabajadores,
        SUM(
          CASE
            WHEN TipoConsumo = 'INVITADO' THEN 1
            ELSE 0
          END
        ) AS Acompanantes
      FROM PersonasUnicas
      GROUP BY
        CodigoServicio,
        NombreServicio
      ORDER BY NombreServicio;
    `)).recordset.map(e=>({codigo:e.CodigoServicio,nombre:e.NombreServicio,trabajadores:Number(e.Trabajadores),acompanantes:Number(e.Acompanantes)}));function a(e){let o=e.reduce((e,o)=>e+o.cantidad,0);return{total:o,servicios:e.map(e=>({...e,porcentaje:o>0?Number((e.cantidad/o*100).toFixed(2)):0}))}}let i=a(s.map(e=>({codigo:e.codigo,nombre:e.nombre,cantidad:e.trabajadores})));return{trabajadores:i,acompanantes:a(s.map(e=>({codigo:e.codigo,nombre:e.nombre,cantidad:e.acompanantes}))),general:a(s.map(e=>({codigo:e.codigo,nombre:e.nombre,cantidad:e.trabajadores+e.acompanantes})))}}async function s(e,t){let s=await (0,o.f)();return(await s.request().input("ProgramacionNro",r.sql.Decimal(10,0),Number(e)).input("TipoDetalle",r.sql.NVarChar(20),t).query(`
      ;WITH DetalleBase AS (
        SELECT
          LTRIM(RTRIM(rec.RegistrosConsumosTipo)) AS TipoConsumo,
          LTRIM(RTRIM(ts.TipoServiciosCodigo)) AS CodigoServicio,
          LTRIM(RTRIM(ts.TipoServiciosNombre)) AS NombreServicio,
          CASE
            WHEN LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'PRINCIPAL'
              THEN LTRIM(RTRIM(re.PersonasDocumento))
            WHEN LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'INVITADO'
              THEN LTRIM(RTRIM(rea.RegistrosAcompDocum))
          END AS DocumentoPersona,
          CASE
            WHEN LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'PRINCIPAL'
              THEN p.PersonasNombresComp
            WHEN LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'INVITADO'
              THEN rea.RegistrosAcompNombre
          END AS NombrePersona,
          rec.RegistrosConsumosFec AS FechaConsumo
        FROM dbo.RegistrosEventoConsumos AS rec
        INNER JOIN dbo.RegistrosEvento AS re
          ON re.RegistrosEventoNro = rec.RegistrosEventoNro
        INNER JOIN dbo.TipoServicios AS ts
          ON LTRIM(RTRIM(ts.TipoServiciosCodigo)) =
             LTRIM(RTRIM(rec.TipoServiciosCodigo))
        LEFT JOIN dbo.Personas AS p
          ON LTRIM(RTRIM(p.PersonasDocumento)) =
             LTRIM(RTRIM(re.PersonasDocumento))
        LEFT JOIN dbo.RegistrosEventoAcomp AS rea
          ON rea.RegistrosEventoNro = rec.RegistrosEventoNro
        WHERE re.ProgramacionNro = @ProgramacionNro
          AND LTRIM(RTRIM(rec.RegistrosConsumosTipo))
              IN ('PRINCIPAL', 'INVITADO')
          AND (
            @TipoDetalle = 'general'
            OR (
              @TipoDetalle = 'trabajadores'
              AND LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'PRINCIPAL'
            )
            OR (
              @TipoDetalle = 'acompanantes'
              AND LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'INVITADO'
            )
          )
          AND (
            LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'PRINCIPAL'
            OR rea.RegistrosAcompDocum IS NOT NULL
          )
      )
      SELECT
        TipoConsumo,
        CodigoServicio,
        NombreServicio,
        DocumentoPersona,
        MAX(NombrePersona) AS NombrePersona,
        CAST(FechaConsumo AS DATE) AS FechaConsumo
      FROM DetalleBase
      WHERE DocumentoPersona IS NOT NULL
        AND DocumentoPersona <> ''
      GROUP BY
        TipoConsumo,
        CodigoServicio,
        NombreServicio,
        DocumentoPersona,
        CAST(FechaConsumo AS DATE)
      ORDER BY
        CAST(FechaConsumo AS DATE),
        NombreServicio,
        TipoConsumo,
        DocumentoPersona;
    `)).recordset.map(e=>({tipo:String(e.TipoConsumo).trim(),codigo:String(e.CodigoServicio).trim(),servicio:String(e.NombreServicio).trim(),documento:String(e.DocumentoPersona).trim(),nombre:e.NombrePersona?String(e.NombrePersona).trim():"",fecha:e.FechaConsumo}))}async function a(e){try{let{searchParams:o}=new URL(e.url),r=o.get("programacionNro"),a=o.get("detalle");if(!r||!/^\d+$/.test(r))return Response.json({success:!1,message:"Debes seleccionar una programación válida."},{status:400,headers:{"Cache-Control":"no-store"}});if(a){if(!["trabajadores","acompanantes","general"].includes(a))return Response.json({success:!1,message:"El tipo de detalle no es válido."},{status:400,headers:{"Cache-Control":"no-store"}});let e=await s(r,a);return Response.json({success:!0,data:e},{headers:{"Cache-Control":"no-store"}})}let i=await t(r);return Response.json({success:!0,data:i},{headers:{"Cache-Control":"no-store"}})}catch(e){return console.error("Error consultando comida:",e),Response.json({success:!1,message:"No fue posible consultar los consumos de comida."},{status:500,headers:{"Cache-Control":"no-store"}})}}e.s(["GET",0,a],41417)}]})();

//# sourceMappingURL=eventos_0m250tv08xm5z._.js.map