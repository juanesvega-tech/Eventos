var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/registros/route.js")
R.c("server/chunks/12wx_open_index_0sydji39fdj09.js")
R.c("server/chunks/[root-of-the-server]__1osgy9pd9a_7c._.js")
R.c("server/chunks/[root-of-the-server]__06xsw8hmnszc0._.js")
R.c("server/chunks/12wx_next_1hawuj_ty4qvt._.js")
R.c("server/chunks/eventos_1yyyf_g7c8mq5._.js")
R.c("server/chunks/eventos__next-internal_server_app_api_registros_route_actions_1t_da2ijyaj8e.js")
R.m(99291)
module.exports=R.m(99291).exports
