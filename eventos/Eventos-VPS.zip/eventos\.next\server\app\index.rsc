#1:"$Sreact.fragment"
2:"/_next/static/chunks/2jpgc-kvq-n38.js"
3:I[98285,["$2"],"default"]
4:I[53744,["$2"],"default"]
7:I[31213,["$2"],"ClientPageRoot"]
8:"/_next/static/chunks/39ok_17lh00wf.js"
9:"/_next/static/chunks/10ugxde7rd3rq.js"
a:I[12395,["$2","$8","$9"],"default"]
b:I[61806,["$2"],"OutletBoundary"]
c:"$Sreact.suspense"
f:"ViewportBoundary"
10:I[61806,["$2"],"$f"]
12:"MetadataBoundary"
13:I[61806,["$2"],"$12"]
16:I[31462,["$2"],"default",1]
:HL["/_next/static/chunks/1rgubu1t4f-82.css","style"]
5:X
e:X
6:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","$L7",null,{"Component":"$a","serverProvidedParams":null}],[["$","script","script-0",{"src":"/_next/static/chunks/39ok_17lh00wf.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/10ugxde7rd3rq.js","async":true,"nonce":"$undefined"}]],["$","$Lb",null,{"children":["$","$c",null,{"name":"Next.MetadataOutlet","children":"$@d"}]}]]}],"p":true,"v":"$e"}}]]
15:X
17:X
18:X
0:{"P":null,"c":["",""],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1rgubu1t4f-82.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/2jpgc-kvq-n38.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"es","children":["$","body",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":true,"v":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L10",null,{"children":"$L11"}],["$","$L13",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$c",null,{"name":"Next.Metadata","children":"$L14"}]}],null]}],null]}],"p":true,"v":"$15"}},"m":"$undefined","G":["$16",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1rgubu1t4f-82.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$17","s":"$18","a":"$@19","l":"$undefined","p":"$undefined","d":"$undefined","b":"WtEMasfYzOSD1mSbUHnl-","u":"$@1a"}
e:C
18:300
11:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
d:null
14:[["$","title","0",{"children":"Dashboard de eventos"}],["$","meta","1",{"name":"description","content":"Panel de estadísticas de inscripción y acompañantes de eventos."}]]
18:C
15:C
17:C
5:C
1a:false
19:null
