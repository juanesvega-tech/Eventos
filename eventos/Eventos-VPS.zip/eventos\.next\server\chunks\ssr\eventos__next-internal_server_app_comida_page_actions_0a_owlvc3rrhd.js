module.exports=[57387,(a,b,c)=>{}];

//# sourceMappingURL=eventos__next-internal_server_app_comida_page_actions_0a_owlvc3rrhd.js.map