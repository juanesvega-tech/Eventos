globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Hpr-tIiLYokzikC08AUGN/_buildManifest.js",
    "static/Hpr-tIiLYokzikC08AUGN/_ssgManifest.js",
    "static/Hpr-tIiLYokzikC08AUGN/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1ss5e7cawwl0n.js",
    "static/chunks/2a2d8qeut2-5y.js",
    "static/chunks/07w9oizd16ea9.js",
    "static/chunks/3vl0heiu9k_2v.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1ss5e7cawwl0n.js",
        "static/chunks/2a2d8qeut2-5y.js",
        "static/chunks/07w9oizd16ea9.js",
        "static/chunks/3vl0heiu9k_2v.js"
      ],
      "runtimeModuleIds": [
        35384
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1ss5e7cawwl0n.js",
        "static/chunks/2a2d8qeut2-5y.js",
        "static/chunks/07w9oizd16ea9.js",
        "static/chunks/3vl0heiu9k_2v.js"
      ],
      "runtimeModuleIds": [
        35384
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1ss5e7cawwl0n.js",
        "static/chunks/2a2d8qeut2-5y.js",
        "static/chunks/07w9oizd16ea9.js",
        "static/chunks/3vl0heiu9k_2v.js"
      ],
      "runtimeModuleIds": [
        35384
      ]
    },
    "/comida/page": {
      "otherChunks": [
        "static/chunks/1ss5e7cawwl0n.js",
        "static/chunks/2a2d8qeut2-5y.js",
        "static/chunks/07w9oizd16ea9.js",
        "static/chunks/3vl0heiu9k_2v.js"
      ],
      "runtimeModuleIds": [
        35384
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
