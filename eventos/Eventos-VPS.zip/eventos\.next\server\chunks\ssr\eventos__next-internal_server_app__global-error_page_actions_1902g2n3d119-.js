module.exports=[66663,(a,b,c)=>{}];

//# sourceMappingURL=eventos__next-internal_server_app__global-error_page_actions_1902g2n3d119-.js.map