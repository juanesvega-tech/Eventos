:HL["/_next/static/chunks/3-rnqelz4me3b.css","style"]
2:[["children",{"s":"__PAGE__","h":49314}]]
1:[["children",{"s":"comida","h":49250,"c":"$Q2"}]]
0:{"b":"Hpr-tIiLYokzikC08AUGN","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
