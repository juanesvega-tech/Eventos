module.exports=[34539,(e,o,d)=>{}];

//# sourceMappingURL=eventos__next-internal_server_app_api_comida_costos_route_actions_1m6253lzr9njy.js.map