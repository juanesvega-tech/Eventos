module.exports=[74624,(e,o,d)=>{}];

//# sourceMappingURL=eventos__next-internal_server_app_api_eventos_route_actions_0_qc38--ins5h.js.map