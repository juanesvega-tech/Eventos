module.exports=[56899,(a,b,c)=>{}];

//# sourceMappingURL=eventos__next-internal_server_app_page_actions_1basiq45e-off.js.map