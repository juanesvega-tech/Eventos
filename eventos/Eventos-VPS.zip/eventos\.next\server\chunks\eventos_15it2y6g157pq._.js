(()=>{"use strict";module.exports=[88068,e=>{var t=e.i(49271),o=e.i(77911),r=e.i(282),a=e.i(27149),s=e.i(8987),i=e.i(41178),n=e.i(71678),c=e.i(66403),l=e.i(13696),u=e.i(32924),d=e.i(95479),p=e.i(54823),R=e.i(85486),m=e.i(17128),T=e.i(69375),h=e.i(93695),v=e.i(57564);e.i(23287);var C=e.i(64413);let E=new t.AppRouteRouteModule({definition:{kind:o.f.APP_ROUTE,page:"/api/comida/costos/route",pathname:"/api/comida/costos",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/eventos/src/app/api/comida/costos/route.js",nextConfigOutput:"standalone",userland:()=>e.r(81437),...{}}),{workAsyncStorage:N,workUnitAsyncStorage:g,serverHooks:S}=E;async function A(e,t,r){r.requestMeta&&(0,a.R)(e,r.requestMeta),E.isDev&&(0,a.i)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let N="/api/comida/costos/route";N=N.replace(/\/index$/,"")||"/";let g=await E.prepare(e,t,{srcPage:N,multiZoneDraftMode:!1});if(!g)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:S,deploymentId:A,params:I,nextConfig:f,parsedUrl:P,isDraftMode:w,prerenderManifest:M,routerServerContext:O,isOnDemandRevalidate:x,revalidateOnlyGenerated:b,resolvedPathname:L,clientReferenceManifest:D,serverActionsManifest:y,previewProps:U}=g,H=(0,n.f)(N),k=!!M.routes[L]&&(E.isDev||(0,v.f)(L,E.cacheOwner,M.routes[L])),q=!!(M.dynamicRoutes[H]||k),F=async()=>((null==O?void 0:O.render404)?await O.render404(e,t,P,!1):t.end("This page could not be found"),null);if(q&&!w){let e=M.dynamicRoutes[H];if(e&&!1===e.fallback&&!k){if(f.adapterPath)return await F();throw new h.NoFallbackError}}let V=null;!q||E.isDev||w||(V="/index"===(V=L)?"/":V),y&&D&&(0,i.f)({page:N,clientReferenceManifest:D,serverActionsManifest:y});let B=e.method||"GET",W=(0,s.v)(),_=W.getActiveScopeSpan(),j=!!(null==O?void 0:O.isWrappedByNextServer),G=!!(0,a.w)(e,"minimalMode"),$=(0,a.w)(e,"incrementalCache")||await E.getIncrementalCache(e,f,U,M,G);null==$||$.resetRequestCache(),globalThis.__incrementalCache=$;let J={params:I,previewProps:U,renderOpts:{experimental:{authInterrupts:!!f.experimental.authInterrupts,useCacheTimeout:f.experimental.useCacheTimeout,durableUseCacheEntries:!!f.experimental.durableUseCacheEntries},cacheComponents:!!f.cacheComponents,validationLevel:f.experimental.instantInsights.validationLevel,isDraftMode:w,incrementalCache:$,hmrRefreshHash:(0,a.w)(e,"hmrRefreshHash"),cacheLifeProfiles:f.cacheLife,staticPageGenerationTimeout:f.staticPageGenerationTimeout,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0},sharedContext:{buildId:S,deploymentId:A}},Y=new c.x(e),K=new c.e(t),Q=l.k.fromNodeNextRequest(Y,(0,l.t)(t)),Z=async({previousCacheEntry:o})=>{try{if(!G&&x&&b&&!o)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let a=null===V?await E.handle(Q,J):await E.prerender(Q,J);e.fetchMetrics=J.renderOpts.fetchMetrics;let s=J.renderOpts.pendingWaitUntil;s&&r.waitUntil&&(r.waitUntil(s),s=void 0);let i=J.renderOpts.collectedTags;if(!q)return await (0,p.f)(Y,K,a,s),null;{let e=await a.blob(),t=(0,R.S)(a.headers);i&&(t[T.M]=i),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let o=void 0!==J.renderOpts.collectedRevalidate&&!(J.renderOpts.collectedRevalidate>=T.Q)&&J.renderOpts.collectedRevalidate,r=void 0===J.renderOpts.collectedExpire||J.renderOpts.collectedExpire>=T.Q?!1!==o&&o>0?f.expireTime:void 0:J.renderOpts.collectedExpire;return{value:{kind:C.x.APP_ROUTE,status:a.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:o,expire:r}}}}catch(t){throw(null==o?void 0:o.isStale)&&await E.onRequestError(e,t,{routerKind:"App Router",routePath:N,routeType:"route",revalidateReason:(0,d.f)({isStaticGeneration:null!==V,isOnDemandRevalidate:x})},!1,O),t}},z=async(a,i)=>{try{var n,c;let a=await E.handleResponse({req:e,nextConfig:f,cacheKey:V,routeKind:o.f.APP_ROUTE,isFallback:!1,previewProps:U,prerenderManifest:M,isRoutePPREnabled:!1,isOnDemandRevalidate:x,revalidateOnlyGenerated:b,responseGenerator:Z,waitUntil:r.waitUntil,isMinimalMode:G});if(null!==a&&"error"in a)throw a.error;if(!q)return;if((null==a||null==(n=a.value)?void 0:n.kind)!==C.x.APP_ROUTE)throw Error(`Invariant: app-route received invalid cache entry ${null==a||null==(c=a.value)?void 0:c.kind}`);G||t.setHeader("x-nextjs-cache",x?"REVALIDATED":a.isMiss?"MISS":a.isStale?"STALE":"HIT"),w&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let s=(0,R.G)(a.value.headers);G&&q||s.delete(T.M),!a.cacheControl||t.getHeader("Cache-Control")||s.get("Cache-Control")||s.set("Cache-Control",(0,m.f)(a.cacheControl)),await (0,p.f)(Y,K,new Response(a.value.body,{headers:s,status:a.value.status||200}));return}catch(o){if(o instanceof h.NoFallbackError||await E.onRequestError(e,o,{routerKind:"App Router",routePath:H,routeType:"route",revalidateReason:(0,d.f)({isStaticGeneration:null!==V,isOnDemandRevalidate:x})},!1,O),q)throw o;if(t.headersSent){if(a){let e=o instanceof Error?o:Error("Unknown app route error");a.recordException(e),a.setStatus({code:s.J.ERROR,message:e.message}),a.setAttribute("error.type",e.name)}t.writableEnded||t.destroyed||t.end()}else await (0,p.f)(Y,K,new Response(null,{status:500}));return}finally{(()=>{if(!a)return;let e=t.statusCode;a.setAttributes({"http.status_code":e,"next.rsc":!1}),e&&e>=500&&(a.setStatus({code:s.J.ERROR}),a.setAttribute("error.type",e.toString()));let o=W.getRootSpanAttributes();if(!o)return;if(o.get("next.span_type")!==u.q.handleRequest)return console.warn(`Unexpected root span type '${o.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=o.get("next.route")||H,n=`${B} ${r}`;a.setAttributes({"next.route":r,"http.route":r,"next.span_name":n}),a.updateName(n),i&&i!==a&&(i.setAttribute("http.route",r),i.updateName(n))})()}};if(j&&_)await z(_,void 0);else{let t=W.getActiveScopeSpan();await W.withPropagatedContext(e.headers,()=>W.trace(u.q.handleRequest,{spanName:`${B} ${N}`,kind:s.C.SERVER,attributes:{"http.method":B,"http.target":e.url}},e=>z(e,t)),void 0,!j)}}e.s(["handler",0,A,"patchFetch",0,function(){return(0,r.f)({workAsyncStorage:N,workUnitAsyncStorage:g})},"routeModule",0,E,"serverHooks",0,S,"workAsyncStorage",0,N,"workUnitAsyncStorage",0,g])},81437,e=>{var t=e.i(25392),o=e.i(8528),r=e.i(40437);async function a(e){let t=await (0,o.f)(),a=(await t.request().input("programacionNro",r.sql.Decimal(10,0),Number(e)).query(`
      ;WITH ConsumosBase AS (
        SELECT
          re.ProgramacionNro,
          LTRIM(RTRIM(rec.RegistrosConsumosTipo)) AS TipoConsumo,
          LTRIM(RTRIM(rec.TipoServiciosCodigo)) AS CodigoServicio,
          CAST(rec.RegistrosConsumosFec AS DATE) AS FechaConsumo,
          CASE
            WHEN LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'PRINCIPAL'
              THEN LTRIM(RTRIM(re.PersonasDocumento))
            WHEN LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'INVITADO'
              THEN LTRIM(RTRIM(rea.RegistrosAcompDocum))
          END AS DocumentoPersona,
          rec.RegistrosConsumosHor AS HoraConsumo
        FROM dbo.RegistrosEventoConsumos AS rec
        INNER JOIN dbo.RegistrosEvento AS re
          ON re.RegistrosEventoNro = rec.RegistrosEventoNro
        LEFT JOIN dbo.RegistrosEventoAcomp AS rea
          ON rea.RegistrosEventoNro = rec.RegistrosEventoNro
        WHERE re.ProgramacionNro = @programacionNro
          AND LTRIM(RTRIM(rec.RegistrosConsumosTipo))
              IN ('PRINCIPAL', 'INVITADO')
          AND (
            LTRIM(RTRIM(rec.RegistrosConsumosTipo)) = 'PRINCIPAL'
            OR rea.RegistrosAcompDocum IS NOT NULL
          )
      ),
      ConsumosNumerados AS (
        SELECT
          ProgramacionNro,
          TipoConsumo,
          CodigoServicio,
          FechaConsumo,
          DocumentoPersona,
          ROW_NUMBER() OVER (
            PARTITION BY
              ProgramacionNro,
              DocumentoPersona,
              TipoConsumo,
              CodigoServicio,
              FechaConsumo
            ORDER BY HoraConsumo
          ) AS rn
        FROM ConsumosBase
        WHERE DocumentoPersona IS NOT NULL
          AND DocumentoPersona <> ''
      ),
      ConsumosValidos AS (
        SELECT
          ProgramacionNro,
          TipoConsumo,
          CodigoServicio,
          FechaConsumo,
          DocumentoPersona
        FROM ConsumosNumerados
        WHERE rn = 1
      )
      SELECT
        LTRIM(RTRIM(ts.TipoServiciosCodigo)) AS codigo,
        LTRIM(RTRIM(ts.TipoServiciosNombre)) AS servicio,
        ts.TipoServiciosValor AS valorUnitario,
        COUNT(*) AS cantidadPersonas,
        COUNT(*) * ts.TipoServiciosValor AS costoTotal,
        SUM(
          CASE
            WHEN cv.TipoConsumo = 'PRINCIPAL' THEN 1
            ELSE 0
          END
        ) AS cantidadInvitados,
        SUM(
          CASE
            WHEN cv.TipoConsumo = 'INVITADO' THEN 1
            ELSE 0
          END
        ) AS cantidadAcompanantes
      FROM ConsumosValidos AS cv
      INNER JOIN dbo.TipoServicios AS ts
        ON LTRIM(RTRIM(ts.TipoServiciosCodigo)) =
           cv.CodigoServicio
      GROUP BY
        LTRIM(RTRIM(ts.TipoServiciosCodigo)),
        LTRIM(RTRIM(ts.TipoServiciosNombre)),
        ts.TipoServiciosValor
      ORDER BY costoTotal DESC;
    `)).recordset.map(e=>({codigo:e.codigo,servicio:e.servicio,valorUnitario:Number(e.valorUnitario),cantidadPersonas:Number(e.cantidadPersonas),costoTotal:Number(e.costoTotal),cantidadInvitados:Number(e.cantidadInvitados),cantidadAcompanantes:Number(e.cantidadAcompanantes)})),s=a.reduce((e,t)=>e+t.cantidadPersonas,0),i=a.reduce((e,t)=>e+t.costoTotal,0);return{servicios:a,totalPersonas:s,costoTotal:i}}async function s(e){try{let{searchParams:o}=new URL(e.url),r=o.get("programacionNro");if(!r||!/^\d+$/.test(r))return t.NextResponse.json({success:!1,message:"Programación inválida."},{status:400,headers:{"Cache-Control":"no-store"}});let s=await a(r);return t.NextResponse.json({success:!0,data:s},{headers:{"Cache-Control":"no-store"}})}catch(e){return console.error("Error calculando costos de comida:",e),t.NextResponse.json({success:!1,message:e.message||"Error calculando los costos."},{status:500,headers:{"Cache-Control":"no-store"}})}}e.s(["GET",0,s],81437)}]})();

//# sourceMappingURL=eventos_15it2y6g157pq._.js.map