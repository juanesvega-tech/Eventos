module.exports=[13464,(e,o,d)=>{}];

//# sourceMappingURL=eventos__next-internal_server_app_api_comida_reporte_route_actions_18rctyv96vqzm.js.map