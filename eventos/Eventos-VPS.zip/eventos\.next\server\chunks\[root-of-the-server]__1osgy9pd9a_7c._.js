module.exports=[54799,(e,r,o)=>{r.exports=e.x("crypto",()=>require("crypto"))},70406,(e,r,o)=>{r.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,r,o)=>{r.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},20635,(e,r,o)=>{r.exports=e.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24725,(e,r,o)=>{r.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},34270,(e,r,o)=>{r.exports=e.x("next/dist/server/app-render/module-loading/track-module-loading.external.js",()=>require("next/dist/server/app-render/module-loading/track-module-loading.external.js"))},56704,(e,r,o)=>{r.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,r,o)=>{r.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},59043,(e,r,o)=>{r.exports=e.x("next/dist/server/runtime-reacts.external.js",()=>require("next/dist/server/runtime-reacts.external.js"))},93695,(e,r,o)=>{r.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},74533,(e,r,o)=>{r.exports=e.x("node:child_process",()=>require("node:child_process"))},2157,(e,r,o)=>{r.exports=e.x("node:fs",()=>require("node:fs"))},12714,(e,r,o)=>{r.exports=e.x("node:fs/promises",()=>require("node:fs/promises"))},60526,(e,r,o)=>{r.exports=e.x("node:os",()=>require("node:os"))},50227,(e,r,o)=>{r.exports=e.x("node:path",()=>require("node:path"))},59639,(e,r,o)=>{r.exports=e.x("node:process",()=>require("node:process"))},81111,(e,r,o)=>{r.exports=e.x("node:stream",()=>require("node:stream"))},57764,(e,r,o)=>{r.exports=e.x("node:url",()=>require("node:url"))},12057,(e,r,o)=>{r.exports=e.x("node:util",()=>require("node:util"))},27028,(e,r,o)=>{r.exports=e.x("node:zlib",()=>require("node:zlib"))},14747,(e,r,o)=>{r.exports=e.x("path",()=>require("path"))},24361,(e,r,o)=>{r.exports=e.x("util",()=>require("util"))},40437,e=>{"use strict";var r=e.i(16909);e.s(["sql",()=>r.default])},85,e=>{"use strict";var r=e.i(8528),o=e.i(40437);async function t(e){let t=await (0,r.f)(),s=(await t.request().input("ProgramacionNro",o.sql.Decimal(18,0),e).query(`
      SELECT
        (
          SELECT COUNT(DISTINCT LTRIM(RTRIM(r.PersonasDocumento)))
          FROM dbo.RegistrosEvento AS r
          WHERE r.ProgramacionNro = @ProgramacionNro
            AND LTRIM(RTRIM(r.PersonasDocumento)) <> ''
        ) AS Invitados,

        (
          SELECT COUNT(DISTINCT LTRIM(RTRIM(a.RegistrosAcompDocum)))
          FROM dbo.RegistrosEventoAcomp AS a
          INNER JOIN dbo.RegistrosEvento AS r
            ON r.RegistrosEventoNro = a.RegistrosEventoNro
          WHERE r.ProgramacionNro = @ProgramacionNro
            AND LTRIM(RTRIM(a.RegistrosAcompDocum)) <> ''
        ) AS Acompanantes;
    `)).recordset[0],n=Number(s.Invitados),a=Number(s.Acompanantes);return{invitados:n,acompanantes:a,total:n+a}}async function s(e){let t=await (0,r.f)();return(await t.request().input("ProgramacionNro",o.sql.Decimal(18,0),Number(e)).query(`
      ;WITH Principales AS (
        SELECT
          r.RegistrosEventoNro,
          LTRIM(RTRIM(r.PersonasDocumento)) AS Documento,
          MAX(LTRIM(RTRIM(p.PersonasNombresComp))) AS Nombre
        FROM dbo.RegistrosEvento AS r
        LEFT JOIN dbo.Personas AS p
          ON LTRIM(RTRIM(p.PersonasDocumento)) =
             LTRIM(RTRIM(r.PersonasDocumento))
        WHERE r.ProgramacionNro = @ProgramacionNro
          AND LTRIM(RTRIM(r.PersonasDocumento)) <> ''
        GROUP BY
          r.RegistrosEventoNro,
          LTRIM(RTRIM(r.PersonasDocumento))
      ),
      Acompanantes AS (
        SELECT
          a.RegistrosEventoNro,
          LTRIM(RTRIM(a.RegistrosAcompDocum)) AS Documento,
          MAX(LTRIM(RTRIM(a.RegistrosAcompNombre))) AS Nombre
        FROM dbo.RegistrosEventoAcomp AS a
        INNER JOIN dbo.RegistrosEvento AS r
          ON r.RegistrosEventoNro = a.RegistrosEventoNro
        WHERE r.ProgramacionNro = @ProgramacionNro
          AND LTRIM(RTRIM(a.RegistrosAcompDocum)) <> ''
        GROUP BY
          a.RegistrosEventoNro,
          LTRIM(RTRIM(a.RegistrosAcompDocum))
      )
      SELECT
        p.RegistrosEventoNro,
        p.Documento AS PrincipalDocumento,
        p.Nombre AS PrincipalNombre,
        a.Documento AS InvitadoDocumento,
        a.Nombre AS InvitadoNombre
      FROM Principales p
      LEFT JOIN Acompanantes a
        ON a.RegistrosEventoNro = p.RegistrosEventoNro

      UNION ALL

      SELECT
        a.RegistrosEventoNro,
        '' AS PrincipalDocumento,
        '' AS PrincipalNombre,
        a.Documento AS InvitadoDocumento,
        a.Nombre AS InvitadoNombre
      FROM Acompanantes a
      WHERE NOT EXISTS (
        SELECT 1
        FROM Principales p
        WHERE p.RegistrosEventoNro = a.RegistrosEventoNro
      )
      ORDER BY RegistrosEventoNro;
    `)).recordset}e.s(["J",0,t,"r",0,s])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1osgy9pd9a_7c._.js.map