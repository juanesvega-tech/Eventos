module.exports=[86690,(a,b,c)=>{}];

//# sourceMappingURL=eventos__next-internal_server_app__not-found_page_actions_0l6gfgquvnvvf.js.map