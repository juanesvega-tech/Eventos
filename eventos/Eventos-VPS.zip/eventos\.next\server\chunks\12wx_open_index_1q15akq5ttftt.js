module.exports=[38227,e=>{e.v(r=>Promise.all(["server/chunks/[root-of-the-server]__06cgc0nwdn48v._.js"].map(r=>e.l(r))).then(()=>r(81118)))}];

//# sourceMappingURL=12wx_open_index_1q15akq5ttftt.js.map