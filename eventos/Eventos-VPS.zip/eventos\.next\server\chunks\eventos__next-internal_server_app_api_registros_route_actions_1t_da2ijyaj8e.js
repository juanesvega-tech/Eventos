module.exports=[62892,(e,o,d)=>{}];

//# sourceMappingURL=eventos__next-internal_server_app_api_registros_route_actions_1t_da2ijyaj8e.js.map