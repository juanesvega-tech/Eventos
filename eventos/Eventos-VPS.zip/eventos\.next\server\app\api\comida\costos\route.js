var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/comida/costos/route.js")
R.c("server/chunks/[root-of-the-server]__0q-d4rq15kk_t._.js")
R.c("server/chunks/eventos_15it2y6g157pq._.js")
R.c("server/chunks/[root-of-the-server]__06xsw8hmnszc0._.js")
R.c("server/chunks/12wx_next_1hawuj_ty4qvt._.js")
R.c("server/chunks/eventos__next-internal_server_app_api_comida_costos_route_actions_1m6253lzr9njy.js")
R.m(88068)
module.exports=R.m(88068).exports
