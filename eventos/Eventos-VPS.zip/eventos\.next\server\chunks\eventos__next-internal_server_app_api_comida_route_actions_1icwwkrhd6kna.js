module.exports=[25036,(e,o,d)=>{}];

//# sourceMappingURL=eventos__next-internal_server_app_api_comida_route_actions_1icwwkrhd6kna.js.map