module.exports=[89770,(a,b,c)=>{"use strict";c._=function(a){return a&&a.__esModule?a:{default:a}}}];

//# sourceMappingURL=12wx_%40swc_helpers_cjs__interop_require_default_cjs_06lfq3qseg65y._.js.map